# OUTPOST ZERO — offline mobile FPS starter

This is an original, lightweight pseudo-3D first-person shooter prototype for Android. It includes touch movement/look/fire controls, three weapons, enemy waves, health, score, level progression, generated sound effects, and a simple upgrade screen. The game logic and graphics are bundled locally; it does not need a network connection while playing.

## Important scope note
This is not a full Call of Duty-scale 3D game. It uses a ray-cast pseudo-3D renderer and simple original enemy/operator shapes, not realistic 3D models, animation, voice acting, multiplayer, or COD assets. It does not reproduce the copyrighted Call of Duty Ghost character. The player is an original generic tactical operator seen through a first-person weapon view.

## Build the APK using only an Android phone + GitHub Actions

1. Download and extract `outpost-zero-source.zip` on your phone.
2. On Chrome, sign in at https://github.com and create a **Public** repository named `outpost-zero`.
3. Upload the extracted project files and folders to the repository root. If GitHub's mobile uploader cannot upload folders, use **Add file → Create new file** and create each path from the file list below; paste the contents from the extracted files. Required paths:
   - `index.html`
   - `package.json`
   - `vite.config.js`
   - `capacitor.config.json`
   - `src/style.css`
   - `src/main.js`
4. Create the workflow file by choosing **Add file → Create new file**. Set its path to `.github/workflows/build-apk.yml`. Paste the contents of `build-apk.yml` from this project. Commit it to `main`.
5. Upload `outpost-zero-source.zip` to the repository root as a separate file. This archive should contain the project files listed above, with no extra parent folder.
6. Open the repository's **Actions** tab → **Build Outpost Zero Android APK** → **Run workflow** → **Run workflow**. If the workflow does not appear, refresh Actions after committing the workflow file.
7. Wait for the run to finish with a green check. Open the completed run and scroll to **Artifacts**. Download `Outpost-Zero-debug-APK`.
8. Extract the downloaded artifact ZIP. Tap `app-debug.apk` and allow Chrome / Files to install apps from that source if Android asks. Install and launch **Outpost Zero**.

## Offline behavior
The APK contains the built game files locally. Once installed, gameplay works without mobile data or Wi-Fi. Sound starts after the first tap because Android browsers require a user gesture to activate audio.

## Controls
- Left virtual pad: move forward/back and strafe.
- Drag the right side: turn / aim.
- FIRE: shoot (hold for automatic fire on automatic weapons).
- ↻: reload.
- SWAP: cycle sidearm, assault rifle, and shotgun.
- Pause button: pause / resume.

## Troubleshooting
- If GitHub Actions fails, open the failed run and read the first red step. Common causes are a missing source ZIP, wrong archive layout, or a workflow file not committed at `.github/workflows/build-apk.yml`.
- The workflow expects `outpost-zero-source.zip` at repository root. The ZIP must contain `index.html`, `package.json`, `vite.config.js`, `capacitor.config.json`, and `src/` at its top level.
- This workflow creates an unsigned debug APK for personal installation. It is not a Play Store release build.
